import React, { useState } from 'react';
import { Header } from './components/Header';
import { PromptInput } from './components/PromptInput';
import { PromptOutput } from './components/PromptOutput';
import { useDarkMode } from './hooks/useDarkMode';
import { generateStructuredPrompt } from './utils/promptGenerator';

function App() {
  const { isDarkMode, toggleDarkMode } = useDarkMode();
  const [generatedPrompt, setGeneratedPrompt] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = async (input: string) => {
    setIsGenerating(true);
    
    // Simulate API call delay for better UX
    setTimeout(() => {
      const prompt = generateStructuredPrompt(input);
      setGeneratedPrompt(prompt);
      setIsGenerating(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-slate-900 dark:via-purple-900 dark:to-slate-900 transition-all duration-500">
      <Header isDarkMode={isDarkMode} toggleDarkMode={toggleDarkMode} />
      
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 dark:text-white mb-4">
            Crie Prompts SaaS
            <span className="block bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Estruturados
            </span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Digite naturalmente sua ideia de SaaS e receba um prompt completo e estruturado 
            com todas as especificações técnicas e de design.
          </p>
        </div>

        <PromptInput onGenerate={handleGenerate} isGenerating={isGenerating} />

        {isGenerating && (
          <div className="text-center mt-8">
            <div className="inline-flex items-center space-x-3 bg-white/70 dark:bg-slate-800/70 backdrop-blur-xl rounded-full px-6 py-3 border border-gray-200 dark:border-slate-600">
              <div className="animate-spin rounded-full h-5 w-5 border-2 border-blue-500 border-t-transparent"></div>
              <span className="text-gray-700 dark:text-gray-300 font-medium">
                Gerando seu prompt estruturado...
              </span>
            </div>
          </div>
        )}

        {generatedPrompt && !isGenerating && (
          <PromptOutput generatedPrompt={generatedPrompt} />
        )}

        {!generatedPrompt && !isGenerating && (
          <div className="text-center mt-16">
            <div className="max-w-md mx-auto">
              <div className="bg-white/50 dark:bg-slate-800/50 backdrop-blur-xl rounded-2xl p-8 border border-gray-200 dark:border-slate-600">
                <div className="text-6xl mb-4">✨</div>
                <h3 className="text-xl font-semibold text-gray-800 dark:text-white mb-2">
                  Pronto para começar?
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Digite sua ideia de SaaS acima e veja a mágica acontecer!
                </p>
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="border-t border-gray-200 dark:border-slate-700 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600 dark:text-gray-400">
            <p>&copy; 2025 PromptCraft. Transformando ideias em prompts estruturados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;