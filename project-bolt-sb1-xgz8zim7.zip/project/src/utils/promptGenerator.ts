export const generateStructuredPrompt = (userInput: string): string => {
  const prompt = `Contexto e Descrição do Projeto

Contexto
Desenvolvimento de uma aplicação SaaS (Software as a Service) web moderna focada em: ${userInput}

Descrição do Projeto
Plataforma web responsiva que oferece funcionalidades específicas via assinatura, com arquitetura robusta que suporta crescimento orgânico e escalabilidade horizontal para ${userInput}.

Objetivo Principal
Criar uma solução SaaS completa que seja:
- Escalável e performática
- Segura e confiável
- Acessível e inclusiva
- Rentável e sustentável

Sistema de Temas

Tema Claro
- Background: #ffffff, #f8fafc, #f1f5f9
- Texto: #1e293b, #334155, #64748b
- Primário: #3b82f6, #2563eb
- Secundário: #6366f1, #8b5cf6

Tema Escuro
- Background: #0f172a, #1e293b, #334155
- Texto: #f1f5f9, #e2e8f0, #cbd5e1
- Primário: #60a5fa, #3b82f6
- Secundário: #a78bfa, #8b5cf6

Contraste e Acessibilidade
- WCAG 2.1 AA: Mínimo 4.5:1 para texto normal
- WCAG 2.1 AAA: Mínimo 7:1 para texto pequeno
- Focus indicators: Bordas visíveis em elementos interativos
- Keyboard navigation: Suporte completo para navegação por teclado

Transição Entre Temas
* {
  transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
}

Principais Benefícios
- Redução de fadiga ocular
- Melhor experiência em diferentes ambientes
- Economia de bateria em dispositivos OLED
- Acessibilidade aprimorada

Estrutura do Aplicativo

Páginas e Rotas
/                    Landing page
/auth/login          Login
/auth/register       Registro
/auth/forgot         Recuperação de senha
/dashboard           Dashboard principal
/profile             Perfil do usuário
/settings            Configurações
/billing             Cobrança e assinatura
/admin               Painel administrativo
/api/v1/*           Endpoints da API

Componentes da Interface
- Layout Components: Header, Sidebar, Footer, Container
- Form Components: Input, Select, Checkbox, Button
- Data Components: Table, Card, Modal, Dropdown
- Navigation: Breadcrumb, Pagination, Tabs
- Feedback: Alert, Toast, Loading, Progress

Fluxos Principais

Registro
- Formulário multi-etapas
- Validação em tempo real
- Verificação de email
- Onboarding guiado

Dashboard
- Métricas principais
- Gráficos interativos
- Ações rápidas
- Notifications center

Design System

Tipografia
- Fonte Principal: Inter, -apple-system, BlinkMacSystemFont
- Fonte Monospace: JetBrains Mono, Consolas, Monaco
- Escalas:
  - xs: 12px
  - sm: 14px
  - base: 16px
  - lg: 18px
  - xl: 20px
  - 2xl: 24px
  - 3xl: 30px
  - 4xl: 36px

Imagens Recomendadas
- Unsplash: Fotos profissionais e de alta qualidade
- Undraw.co: Ilustrações SVG customizáveis
- Heroicons: Ícones SVG consistentes
- Feather Icons: Ícones minimalistas

Recursos de UI/UX
- Microinterações: Hover states, click feedback
- Loading states: Skeletons, spinners, progress bars
- Empty states: Ilustrações e calls-to-action
- Error states: Mensagens claras e ações de recuperação

Animações
/* Transições suaves */
.smooth-transition {
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}

/* Entrada de elementos */
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Loading */
@keyframes spin {
  to { transform: rotate(360deg); }
}

Responsividade

Breakpoints
- Mobile: 320px - 768px
- Tablet: 768px - 1024px
- Desktop: 1024px - 1440px
- Large: 1440px+

Estratégia Mobile-First
/* Mobile primeiro */
.component { /* estilos mobile */ }

/* Tablet */
@media (min-width: 768px) { /* estilos tablet */ }

/* Desktop */
@media (min-width: 1024px) { /* estilos desktop */ }

Segurança Visual

Observações
- Mascaramento de dados sensíveis
- Watermarks em documentos
- Prevenção de screenshots em dados críticos
- Timeout visual para sessões inativas

Sistema de Autenticação
- Login/logout visual feedback
- Indicadores de força de senha
- Verificação em duas etapas (2FA)
- Sessões ativas visíveis

Features Específicas

Interface Principal
- Workspace: Área de trabalho principal
- Quick Actions: Ações rápidas contextuais
- Search: Busca global inteligente
- Notifications: Centro de notificações

Recursos Mobile
- Touch gestures: Swipe, pinch, tap
- Offline support: Cache inteligente
- Push notifications: Engajamento móvel
- App-like experience: PWA

Elementos de Interface
- Data visualization: Gráficos e dashboards
- Real-time updates: WebSocket connections
- Drag & drop: Interface intuitiva
- Keyboard shortcuts: Produtividade avançada

Recursos Extras

Integrações
- API REST/GraphQL: Integrações externas
- Webhooks: Eventos automatizados
- Third-party services: Pagamentos, email, analytics
- Export/Import: Dados em múltiplos formatos

Analytics
- User behavior: Tracking de interações
- Performance metrics: Core Web Vitals
- Business metrics: KPIs específicos
- A/B testing: Otimização contínua

Tecnologias Base

Frontend
- Framework: React 18+ com TypeScript
- State Management: Zustand/Redux Toolkit
- Routing: React Router v6
- Build Tool: Vite
- Testing: Jest + React Testing Library

Backend
- Runtime: Node.js 18+ LTS
- Framework: Express.js/Fastify
- Database: PostgreSQL + Redis
- ORM: Prisma/TypeORM
- Authentication: JWT + Passport.js

Estilização e UI

CSS Framework
- Tailwind CSS: Utility-first framework
- Headless UI: Componentes acessíveis
- Framer Motion: Animações avançadas
- CSS Modules: Escopo local quando necessário

Componentes
- Radix UI: Primitivos acessíveis
- React Hook Form: Formulários performáticos
- React Query: Estado do servidor
- Date-fns: Manipulação de datas

Stack Tecnológica

Desenvolvimento
- Frontend: React + TypeScript + Tailwind CSS
- Backend: Node.js + Express + PostgreSQL
- Cache: Redis
- File Storage: AWS S3/CloudFlare R2
- CDN: CloudFlare
- Monitoring: DataDog/New Relic

DevOps
- Containers: Docker + Docker Compose
- Orchestration: Kubernetes
- CI/CD: GitHub Actions
- Infrastructure: Terraform
- Monitoring: Prometheus + Grafana

Boas Práticas

Código
- TypeScript: Tipagem estática obrigatória
- ESLint + Prettier: Padronização de código
- Conventional Commits: Histórico organizizado
- Code Reviews: Peer review obrigatório

Performance
- Code Splitting: Lazy loading de rotas
- Image Optimization: WebP, lazy loading
- Caching Strategy: Browser + CDN + Redis
- Bundle Analysis: Monitoramento de tamanho

Segurança
- Content Security Policy: Headers de segurança
- Rate Limiting: Proteção contra abuse
- Input Validation: Sanitização de dados
- HTTPS Everywhere: Criptografia obrigatória

Acessibilidade
- ARIA labels: Elementos semânticos
- Keyboard navigation: Suporte completo
- Screen readers: Compatibilidade total
- Color contrast: WCAG 2.1 AA/AAA

Monitoramento
- Error tracking: Sentry/LogRocket
- Performance monitoring: Core Web Vitals
- Uptime monitoring: Pingdom
- User analytics: Mixpanel/Amplitude

Testes
- Unit tests: Jest + Testing Library
- Integration tests: Cypress/Playwright
- E2E tests: Automated user flows
- Load testing: K6/Artillery

Este guia serve como base para desenvolvimento de aplicações SaaS robustas e escaláveis, adaptável para diferentes tipos de negócio e requisitos específicos.`;

  return prompt;
};