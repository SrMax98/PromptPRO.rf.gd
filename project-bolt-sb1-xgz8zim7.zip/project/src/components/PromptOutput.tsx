import React, { useState } from 'react';
import { Copy, Check, Download, Edit3, Save, X, Share2, FileText, Mail, Printer, SkipForward } from 'lucide-react';
import { useTypewriter } from '../hooks/useTypewriter';

interface PromptOutputProps {
  generatedPrompt: string;
}

export const PromptOutput: React.FC<PromptOutputProps> = ({ generatedPrompt }) => {
  const [copied, setCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedPrompt, setEditedPrompt] = useState(generatedPrompt);
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  // Typewriter effect
  const { displayedText, isTyping, isComplete, skipToEnd } = useTypewriter({
    text: generatedPrompt,
    speed: 15, // Faster typing speed
    startDelay: 500
  });

  const handleCopy = async () => {
    const textToCopy = isEditing ? editedPrompt : (isComplete ? generatedPrompt : displayedText);
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = textToCopy;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownload = (format: 'txt' | 'md' | 'pdf') => {
    const content = isEditing ? editedPrompt : generatedPrompt;
    const timestamp = new Date().toISOString().split('T')[0];
    
    if (format === 'txt') {
      const element = document.createElement('a');
      const file = new Blob([content], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = `saas-prompt-${timestamp}.txt`;
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    } else if (format === 'md') {
      const element = document.createElement('a');
      const file = new Blob([content], { type: 'text/markdown' });
      element.href = URL.createObjectURL(file);
      element.download = `saas-prompt-${timestamp}.md`;
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    } else if (format === 'pdf') {
      // For PDF, we'll create a printable version
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>SaaS Prompt - ${timestamp}</title>
              <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; margin: 40px; }
                h1, h2, h3 { color: #333; }
                pre { background: #f5f5f5; padding: 15px; border-radius: 5px; overflow-x: auto; }
              </style>
            </head>
            <body>
              <h1>SaaS Prompt Estruturado</h1>
              <p><strong>Gerado em:</strong> ${new Date().toLocaleDateString('pt-BR')}</p>
              <hr>
              <pre>${content}</pre>
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  const handleSave = () => {
    setSaveStatus('saving');
    // Simulate save to localStorage or API
    setTimeout(() => {
      localStorage.setItem('saved-prompt', editedPrompt);
      localStorage.setItem('saved-prompt-date', new Date().toISOString());
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 2000);
    }, 1000);
  };

  const handleShare = (platform: 'email' | 'copy-link') => {
    const content = isEditing ? editedPrompt : generatedPrompt;
    
    if (platform === 'email') {
      const subject = encodeURIComponent('Prompt SaaS Estruturado');
      const body = encodeURIComponent(`Confira este prompt SaaS estruturado:\n\n${content}`);
      window.open(`mailto:?subject=${subject}&body=${body}`);
    } else if (platform === 'copy-link') {
      // Create a shareable link (in a real app, this would be a proper sharing URL)
      const shareableContent = `Prompt SaaS Estruturado:\n\n${content}`;
      navigator.clipboard.writeText(shareableContent);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
    setShowShareMenu(false);
  };

  const handlePrint = () => {
    const content = isEditing ? editedPrompt : generatedPrompt;
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>SaaS Prompt - ${new Date().toLocaleDateString('pt-BR')}</title>
            <style>
              body { 
                font-family: 'Courier New', monospace; 
                line-height: 1.6; 
                margin: 40px; 
                font-size: 12px;
              }
              h1 { color: #333; border-bottom: 2px solid #333; padding-bottom: 10px; }
              .header { margin-bottom: 30px; }
              .content { white-space: pre-wrap; }
              @media print {
                body { margin: 20px; }
                .no-print { display: none; }
              }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>SaaS Prompt Estruturado</h1>
              <p><strong>Gerado em:</strong> ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</p>
              <p><strong>Ferramenta:</strong> PromptCraft - Gerador de Prompts SaaS</p>
            </div>
            <div class="content">${content}</div>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const toggleEdit = () => {
    if (isEditing) {
      setEditedPrompt(editedPrompt);
    } else {
      setEditedPrompt(generatedPrompt);
    }
    setIsEditing(!isEditing);
  };

  const cancelEdit = () => {
    setEditedPrompt(generatedPrompt);
    setIsEditing(false);
  };

  return (
    <div className="w-full max-w-4xl mx-auto mt-8">
      <div className="bg-white/70 dark:bg-slate-800/70 backdrop-blur-xl rounded-2xl border border-gray-200 dark:border-slate-600 shadow-xl">
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                Prompt SaaS Estruturado
              </h2>
              {isTyping && (
                <div className="flex items-center space-x-2 text-sm text-blue-600 dark:text-blue-400">
                  <div className="animate-pulse w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>Gerando...</span>
                </div>
              )}
            </div>
            
            <div className="flex items-center space-x-2">
              {/* Skip Typing Button */}
              {isTyping && (
                <button
                  onClick={skipToEnd}
                  className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                  title="Pular animação"
                >
                  <SkipForward className="h-4 w-4" />
                </button>
              )}

              {/* Edit Button - only show when typing is complete */}
              {isComplete && (
                <button
                  onClick={toggleEdit}
                  className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                  title={isEditing ? "Parar edição" : "Editar prompt"}
                >
                  {isEditing ? <X className="h-4 w-4" /> : <Edit3 className="h-4 w-4" />}
                </button>
              )}

              {/* Save Button (only visible when editing) */}
              {isEditing && (
                <button
                  onClick={handleSave}
                  disabled={saveStatus === 'saving'}
                  className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors disabled:opacity-50"
                  title="Salvar alterações"
                >
                  {saveStatus === 'saving' ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-500 border-t-transparent"></div>
                  ) : saveStatus === 'saved' ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : (
                    <Save className="h-4 w-4" />
                  )}
                </button>
              )}
              
              {/* Copy Button */}
              <button
                onClick={handleCopy}
                className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                title="Copiar prompt"
              >
                {copied ? (
                  <Check className="h-4 w-4 text-green-500" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
              </button>

              {/* Print Button */}
              {isComplete && (
                <button
                  onClick={handlePrint}
                  className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                  title="Imprimir prompt"
                >
                  <Printer className="h-4 w-4" />
                </button>
              )}
              
              {/* Download Button */}
              {isComplete && (
                <button
                  onClick={() => handleDownload('txt')}
                  className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                  title="Baixar como TXT"
                >
                  <Download className="h-4 w-4" />
                </button>
              )}

              {/* Share Button */}
              {isComplete && (
                <div className="relative">
                  <button
                    onClick={() => setShowShareMenu(!showShareMenu)}
                    className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                    title="Compartilhar prompt"
                  >
                    <Share2 className="h-4 w-4" />
                  </button>

                  {showShareMenu && (
                    <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 rounded-lg shadow-lg border border-gray-200 dark:border-slate-600 z-10">
                      <div className="py-2">
                        <button
                          onClick={() => handleShare('email')}
                          className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 flex items-center space-x-2"
                        >
                          <Mail className="h-4 w-4" />
                          <span>Enviar por email</span>
                        </button>
                        <button
                          onClick={() => handleShare('copy-link')}
                          className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 flex items-center space-x-2"
                        >
                          <Copy className="h-4 w-4" />
                          <span>Copiar conteúdo</span>
                        </button>
                        <button
                          onClick={() => handleDownload('md')}
                          className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 flex items-center space-x-2"
                        >
                          <FileText className="h-4 w-4" />
                          <span>Baixar como Markdown</span>
                        </button>
                        <button
                          onClick={() => handleDownload('pdf')}
                          className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 flex items-center space-x-2"
                        >
                          <FileText className="h-4 w-4" />
                          <span>Imprimir como PDF</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="relative">
            {isEditing ? (
              <textarea
                value={editedPrompt}
                onChange={(e) => setEditedPrompt(e.target.value)}
                className="w-full h-96 p-4 bg-gray-50 dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-xl font-mono text-sm text-gray-800 dark:text-gray-200 resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Edite seu prompt aqui..."
              />
            ) : (
              <div className="bg-gray-50 dark:bg-slate-700 rounded-xl p-4 max-h-96 overflow-y-auto">
                <pre className="font-mono text-sm text-gray-800 dark:text-gray-200 whitespace-pre-wrap">
                  {displayedText}
                  {isTyping && (
                    <span className="animate-pulse bg-blue-500 text-blue-500 ml-1">|</span>
                  )}
                </pre>
              </div>
            )}
          </div>

          {isEditing && (
            <div className="mt-4 flex justify-end space-x-2">
              <button
                onClick={cancelEdit}
                className="px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={toggleEdit}
                className="px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 transition-colors"
              >
                Salvar Alterações
              </button>
            </div>
          )}

          {/* Status Messages */}
          {copied && (
            <div className="mt-4 p-3 bg-green-100 dark:bg-green-900/30 border border-green-200 dark:border-green-800 rounded-lg">
              <p className="text-sm text-green-800 dark:text-green-200 flex items-center">
                <Check className="h-4 w-4 mr-2" />
                Prompt copiado para a área de transferência!
              </p>
            </div>
          )}

          {saveStatus === 'saved' && (
            <div className="mt-4 p-3 bg-blue-100 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800 rounded-lg">
              <p className="text-sm text-blue-800 dark:text-blue-200 flex items-center">
                <Save className="h-4 w-4 mr-2" />
                Alterações salvas com sucesso!
              </p>
            </div>
          )}

          {/* Typing Progress */}
          {isTyping && (
            <div className="mt-4">
              <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 mb-1">
                <span>Gerando prompt estruturado...</span>
                <span>{Math.round((displayedText.length / generatedPrompt.length) * 100)}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-slate-600 rounded-full h-1">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-purple-600 h-1 rounded-full transition-all duration-300"
                  style={{ width: `${(displayedText.length / generatedPrompt.length) * 100}%` }}
                ></div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Click outside to close share menu */}
      {showShareMenu && (
        <div 
          className="fixed inset-0 z-0" 
          onClick={() => setShowShareMenu(false)}
        />
      )}
    </div>
  );
};