import React, { useState } from 'react';
import { Send, Loader2, Lightbulb, History, Bookmark } from 'lucide-react';

interface PromptInputProps {
  onGenerate: (input: string) => void;
  isGenerating: boolean;
}

export const PromptInput: React.FC<PromptInputProps> = ({ onGenerate, isGenerating }) => {
  const [input, setInput] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  const suggestions = [
    "Quero criar um app de gestão de tarefas para equipes remotas com colaboração em tempo real",
    "Preciso de uma plataforma de e-learning com gamificação e certificados",
    "Desenvolver um sistema de CRM para pequenas empresas com automação de vendas",
    "Criar uma ferramenta de análise de dados com dashboards interativos",
    "Plataforma de marketplace para freelancers com sistema de pagamentos",
    "App de fitness com personal trainer virtual e acompanhamento nutricional"
  ];

  const getHistory = () => {
    const history = localStorage.getItem('prompt-history');
    return history ? JSON.parse(history) : [];
  };

  const saveToHistory = (prompt: string) => {
    const history = getHistory();
    const newEntry = {
      id: Date.now(),
      text: prompt,
      date: new Date().toISOString()
    };
    const updatedHistory = [newEntry, ...history.slice(0, 9)]; // Keep only last 10
    localStorage.setItem('prompt-history', JSON.stringify(updatedHistory));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isGenerating) {
      saveToHistory(input.trim());
      onGenerate(input.trim());
      setShowSuggestions(false);
      setShowHistory(false);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInput(suggestion);
    setShowSuggestions(false);
  };

  const handleHistoryClick = (historyItem: string) => {
    setInput(historyItem);
    setShowHistory(false);
  };

  const clearHistory = () => {
    localStorage.removeItem('prompt-history');
    setShowHistory(false);
  };

  const saveAsFavorite = () => {
    if (input.trim()) {
      const favorites = JSON.parse(localStorage.getItem('prompt-favorites') || '[]');
      const newFavorite = {
        id: Date.now(),
        text: input.trim(),
        date: new Date().toISOString()
      };
      const updatedFavorites = [newFavorite, ...favorites];
      localStorage.setItem('prompt-favorites', JSON.stringify(updatedFavorites));
      
      // Show success message
      const button = document.querySelector('[data-favorite-btn]') as HTMLElement;
      if (button) {
        const originalText = button.innerHTML;
        button.innerHTML = '<svg class="h-4 w-4 text-yellow-500" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>';
        setTimeout(() => {
          button.innerHTML = originalText;
        }, 2000);
      }
    }
  };

  const history = getHistory();

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="bg-white/70 dark:bg-slate-800/70 backdrop-blur-xl rounded-2xl border border-gray-200 dark:border-slate-600 shadow-xl">
        <form onSubmit={handleSubmit} className="p-6">
          <div className="flex items-center justify-between mb-3">
            <label htmlFor="prompt-input" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Descreva seu SaaS em linguagem natural
            </label>
            
            <div className="flex items-center space-x-2">
              {/* Favorites Button */}
              <button
                type="button"
                onClick={saveAsFavorite}
                disabled={!input.trim()}
                data-favorite-btn
                className="p-2 text-gray-500 dark:text-gray-400 hover:text-yellow-500 dark:hover:text-yellow-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                title="Salvar como favorito"
              >
                <Bookmark className="h-4 w-4" />
              </button>

              {/* History Button */}
              <button
                type="button"
                onClick={() => setShowHistory(!showHistory)}
                className="p-2 text-gray-500 dark:text-gray-400 hover:text-blue-500 dark:hover:text-blue-400 transition-colors"
                title="Ver histórico"
              >
                <History className="h-4 w-4" />
              </button>

              {/* Suggestions Button */}
              <button
                type="button"
                onClick={() => setShowSuggestions(!showSuggestions)}
                className="p-2 text-gray-500 dark:text-gray-400 hover:text-purple-500 dark:hover:text-purple-400 transition-colors"
                title="Ver sugestões"
              >
                <Lightbulb className="h-4 w-4" />
              </button>
            </div>
          </div>
          
          <div className="relative">
            <textarea
              id="prompt-input"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ex: Quero criar um app de gestão de tarefas para equipes remotas com colaboração em tempo real..."
              className="w-full h-32 px-4 py-3 bg-gray-50 dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-xl resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:text-white placeholder-gray-500 dark:placeholder-gray-400 transition-all"
              disabled={isGenerating}
              maxLength={1000}
            />
            
            <button
              type="submit"
              disabled={!input.trim() || isGenerating}
              className="absolute bottom-3 right-3 p-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform hover:scale-105 active:scale-95"
            >
              {isGenerating ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <Send className="h-5 w-5" />
              )}
            </button>
          </div>
          
          <div className="mt-4 flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
            <span>Digite naturalmente o que você quer criar</span>
            <span className={input.length > 800 ? 'text-orange-500' : ''}>{input.length}/1000</span>
          </div>
        </form>

        {/* Suggestions Panel */}
        {showSuggestions && (
          <div className="border-t border-gray-200 dark:border-slate-600 p-4">
            <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3 flex items-center">
              <Lightbulb className="h-4 w-4 mr-2" />
              Sugestões de Prompts
            </h3>
            <div className="space-y-2">
              {suggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="w-full text-left p-3 bg-gray-50 dark:bg-slate-700 hover:bg-gray-100 dark:hover:bg-slate-600 rounded-lg text-sm text-gray-700 dark:text-gray-300 transition-colors"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* History Panel */}
        {showHistory && (
          <div className="border-t border-gray-200 dark:border-slate-600 p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center">
                <History className="h-4 w-4 mr-2" />
                Histórico Recente
              </h3>
              {history.length > 0 && (
                <button
                  onClick={clearHistory}
                  className="text-xs text-red-500 hover:text-red-600 transition-colors"
                >
                  Limpar histórico
                </button>
              )}
            </div>
            
            {history.length === 0 ? (
              <p className="text-sm text-gray-500 dark:text-gray-400 italic">
                Nenhum prompt no histórico ainda
              </p>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {history.map((item: any) => (
                  <button
                    key={item.id}
                    onClick={() => handleHistoryClick(item.text)}
                    className="w-full text-left p-3 bg-gray-50 dark:bg-slate-700 hover:bg-gray-100 dark:hover:bg-slate-600 rounded-lg transition-colors"
                  >
                    <div className="text-sm text-gray-700 dark:text-gray-300 truncate">
                      {item.text}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      {new Date(item.date).toLocaleDateString('pt-BR')} às {new Date(item.date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Click outside to close panels */}
      {(showSuggestions || showHistory) && (
        <div 
          className="fixed inset-0 z-0" 
          onClick={() => {
            setShowSuggestions(false);
            setShowHistory(false);
          }}
        />
      )}
    </div>
  );
};