import React, { useState } from 'react';
import { Sparkles, Moon, Sun, User, Settings, LogOut, HelpCircle, Star } from 'lucide-react';

interface HeaderProps {
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

export const Header: React.FC<HeaderProps> = ({ isDarkMode, toggleDarkMode }) => {
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showHelpMenu, setShowHelpMenu] = useState(false);

  const handleUserAction = (action: string) => {
    setShowUserMenu(false);
    
    switch (action) {
      case 'profile':
        // In a real app, this would navigate to profile page
        console.log('Navigating to profile...');
        break;
      case 'settings':
        // In a real app, this would open settings modal
        console.log('Opening settings...');
        break;
      case 'logout':
        // In a real app, this would handle logout
        console.log('Logging out...');
        localStorage.removeItem('user-session');
        break;
    }
  };

  const handleHelpAction = (action: string) => {
    setShowHelpMenu(false);
    
    switch (action) {
      case 'guide':
        // Open help guide
        window.open('https://docs.promptcraft.com/guide', '_blank');
        break;
      case 'shortcuts':
        // Show keyboard shortcuts modal
        alert('Atalhos do teclado:\n\nCtrl + Enter: Gerar prompt\nCtrl + C: Copiar resultado\nCtrl + S: Salvar prompt\nEsc: Fechar painéis');
        break;
      case 'feedback':
        // Open feedback form
        window.open('mailto:feedback@promptcraft.com?subject=Feedback PromptCraft', '_blank');
        break;
      case 'about':
        // Show about modal
        alert('PromptCraft v1.0\n\nGerador de Prompts SaaS Estruturados\nDesenvolvido com React + TypeScript + Tailwind CSS\n\n© 2025 PromptCraft');
        break;
    }
  };

  const showRating = () => {
    const rating = prompt('Avalie nossa ferramenta de 1 a 5 estrelas:');
    if (rating && parseInt(rating) >= 1 && parseInt(rating) <= 5) {
      alert(`Obrigado pela sua avaliação de ${rating} estrelas! 🌟`);
      localStorage.setItem('user-rating', rating);
    }
  };

  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-white/80 dark:bg-slate-900/80 border-b border-gray-200 dark:border-slate-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl">
              <Sparkles className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                PromptCraft
              </h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">SaaS Prompt Generator</p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {/* Rating Button */}
            <button
              onClick={showRating}
              className="p-2 rounded-lg bg-gray-100 dark:bg-slate-800 hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors"
              title="Avaliar ferramenta"
            >
              <Star className="h-5 w-5 text-gray-600 dark:text-gray-300" />
            </button>

            {/* Help Menu */}
            <div className="relative">
              <button
                onClick={() => setShowHelpMenu(!showHelpMenu)}
                className="p-2 rounded-lg bg-gray-100 dark:bg-slate-800 hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors"
                title="Ajuda"
              >
                <HelpCircle className="h-5 w-5 text-gray-600 dark:text-gray-300" />
              </button>

              {showHelpMenu && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 rounded-lg shadow-lg border border-gray-200 dark:border-slate-600">
                  <div className="py-2">
                    <button
                      onClick={() => handleHelpAction('guide')}
                      className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700"
                    >
                      Guia de uso
                    </button>
                    <button
                      onClick={() => handleHelpAction('shortcuts')}
                      className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700"
                    >
                      Atalhos do teclado
                    </button>
                    <button
                      onClick={() => handleHelpAction('feedback')}
                      className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700"
                    >
                      Enviar feedback
                    </button>
                    <button
                      onClick={() => handleHelpAction('about')}
                      className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700"
                    >
                      Sobre
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Theme Toggle */}
            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-lg bg-gray-100 dark:bg-slate-800 hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors"
              title={isDarkMode ? "Modo claro" : "Modo escuro"}
            >
              {isDarkMode ? (
                <Sun className="h-5 w-5 text-gray-600 dark:text-gray-300" />
              ) : (
                <Moon className="h-5 w-5 text-gray-600 dark:text-gray-300" />
              )}
            </button>
            
            {/* User Menu */}
            <div className="relative">
              <button 
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="p-2 rounded-lg bg-gray-100 dark:bg-slate-800 hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors"
                title="Menu do usuário"
              >
                <User className="h-5 w-5 text-gray-600 dark:text-gray-300" />
              </button>

              {showUserMenu && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 rounded-lg shadow-lg border border-gray-200 dark:border-slate-600">
                  <div className="py-2">
                    <div className="px-4 py-2 border-b border-gray-200 dark:border-slate-600">
                      <p className="text-sm font-medium text-gray-900 dark:text-white">Usuário</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">user@promptcraft.com</p>
                    </div>
                    <button
                      onClick={() => handleUserAction('profile')}
                      className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 flex items-center space-x-2"
                    >
                      <User className="h-4 w-4" />
                      <span>Perfil</span>
                    </button>
                    <button
                      onClick={() => handleUserAction('settings')}
                      className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 flex items-center space-x-2"
                    >
                      <Settings className="h-4 w-4" />
                      <span>Configurações</span>
                    </button>
                    <hr className="my-1 border-gray-200 dark:border-slate-600" />
                    <button
                      onClick={() => handleUserAction('logout')}
                      className="w-full px-4 py-2 text-left text-sm text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-slate-700 flex items-center space-x-2"
                    >
                      <LogOut className="h-4 w-4" />
                      <span>Sair</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Click outside to close menus */}
      {(showUserMenu || showHelpMenu) && (
        <div 
          className="fixed inset-0 z-0" 
          onClick={() => {
            setShowUserMenu(false);
            setShowHelpMenu(false);
          }}
        />
      )}
    </header>
  );
};